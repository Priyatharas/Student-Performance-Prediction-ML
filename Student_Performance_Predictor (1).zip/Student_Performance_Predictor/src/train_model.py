from pathlib import Path
import pickle

import pandas as pd
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

# Find the main project folder, even if this file is run from another folder.
PROJECT_DIR = Path(__file__).resolve().parents[1]
DATA_PATH = PROJECT_DIR / "data" / "student_data.csv"
MODEL_DIR = PROJECT_DIR / "models"
MODEL_PATH = MODEL_DIR / "student_model.pkl"

# 1. Read the student dataset.
data = pd.read_csv(DATA_PATH)
print("First five student records:")
print(data.head())

# 2. Separate input features (X) from the target label (y).
X = data[["study_hours", "attendance", "previous_marks"]]
y = data["result"]

# 3. Split records: 80% for learning and 20% for testing.
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# 4. Create and train a simple Decision Tree model.
model = DecisionTreeClassifier(max_depth=3, random_state=42)
model.fit(X_train, y_train)

# 5. Evaluate the model on records it did not train on.
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)

print("\nTraining completed.")
print(f"Test accuracy: {accuracy * 100:.2f}%")
print("\nClassification report:")
print(classification_report(y_test, predictions, zero_division=0))

# 6. Save the trained model for predict.py to use.
MODEL_DIR.mkdir(parents=True, exist_ok=True)
with MODEL_PATH.open("wb") as model_file:
    pickle.dump(model, model_file)

print(f"Trained model saved to: {MODEL_PATH}")
print("Next, run: python src/predict.py")
