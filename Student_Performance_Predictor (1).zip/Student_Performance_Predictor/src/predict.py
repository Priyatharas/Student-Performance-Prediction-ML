from pathlib import Path
import pickle

import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parents[1]
MODEL_PATH = PROJECT_DIR / "models" / "student_model.pkl"


def get_number(prompt, minimum, maximum):
    """Ask until the user enters a number within the allowed range."""
    while True:
        try:
            value = float(input(prompt))
            if minimum <= value <= maximum:
                return value
            print(f"Please enter a value from {minimum} to {maximum}.")
        except ValueError:
            print("Please enter a valid number (for example, 7 or 7.5).")


def main():
    if not MODEL_PATH.exists():
        print("The trained model was not found.")
        print("First run: python src/train_model.py")
        return

    # Load the model that was trained and saved earlier.
    with MODEL_PATH.open("rb") as model_file:
        model = pickle.load(model_file)

    print("=" * 40)
    print("      STUDENT PERFORMANCE PREDICTOR")
    print("=" * 40)

    study_hours = get_number("Study hours per day (0-24): ", 0, 24)
    attendance = get_number("Attendance percentage (0-100): ", 0, 100)
    previous_marks = get_number("Previous marks (0-100): ", 0, 100)

    # Use the same feature names and order used during training.
    student = pd.DataFrame(
        [[study_hours, attendance, previous_marks]],
        columns=["study_hours", "attendance", "previous_marks"],
    )

    result = model.predict(student)[0]

    print("\nStudent details:")
    print(f"Study hours: {study_hours}")
    print(f"Attendance: {attendance}%")
    print(f"Previous marks: {previous_marks}")

    print("\nAI prediction:")
    if result == "Pass":
        print("The student is likely to PASS.")
    else:
        print("The student is likely to FAIL.")

    print("\nNote: This is a classroom demonstration, not a reliable real-world")
    print("assessment. The model learned from a small synthetic dataset.")


if __name__ == "__main__":
    main()
