# Student Performance Predictor Using Machine Learning

A very small, beginner-friendly Python project that uses a **Decision Tree Classifier** to predict whether a student is likely to pass or fail.

> **Important:** The CSV data is synthetic (made up for practice). This project demonstrates the machine-learning workflow; it is not suitable for making real decisions about students.

## 1. What does the project do?

It uses three inputs:
- `study_hours`: hours studied per day
- `attendance`: attendance percentage
- `previous_marks`: marks in a previous examination

The model learns from example records in `data/student_data.csv`. You can then enter a new student's details and ask the trained model for a prediction.

## 2. Project files

```text
Student_Performance_Predictor/
├── data/
│   └── student_data.csv
├── models/
│   └── (student_model.pkl is created after training)
├── src/
│   ├── train_model.py
│   └── predict.py
├── README.md
├── requirements.txt
├── .gitignore
└── run_project.bat
```

## 3. Machine-learning ideas in simple language

- **Artificial Intelligence (AI):** A broad area of computing that includes systems performing tasks that seem intelligent.
- **Machine Learning (ML):** A way for a computer to learn patterns from examples.
- **Supervised learning:** Learning from examples that include the correct answer.
- **Dataset:** A collection of example records. Here, each row describes one student.
- **Features (`X`):** The input columns: study hours, attendance and previous marks.
- **Label (`y`):** The answer the model learns to predict: Pass or Fail.
- **Training:** Showing the model examples so it can learn patterns.
- **Testing:** Checking the model on examples that were held back during training.
- **Accuracy:** The fraction of test predictions that matched the known labels.
- **Decision Tree:** An algorithm that learns a sequence of feature-based splits, somewhat like a flowchart.

## 4. Requirements

Install Python 3.10 or newer and Visual Studio Code. In VS Code, open this project folder and open **Terminal → New Terminal**.

### Windows (PowerShell)

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If PowerShell blocks activation, you can use Command Prompt instead:

```bat
.venv\Scripts\activate.bat
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## 5. Run the project

Run these commands from the main `Student_Performance_Predictor` folder.

### Step A: Train and save the model

```bash
python src/train_model.py
```

The program reads the CSV, splits the data into training and testing sets, trains a Decision Tree, prints test accuracy and saves the model to `models/student_model.pkl`.

### Step B: Predict for a new student

```bash
python src/predict.py
```

Enter values when prompted. The program checks that:
- Study hours are between 0 and 24.
- Attendance is between 0 and 100.
- Previous marks are between 0 and 100.

If the saved model does not exist, train it first.

## 6. Sample interaction

```text
========================================
      STUDENT PERFORMANCE PREDICTOR
========================================
Study hours per day (0-24): 8
Attendance percentage (0-100): 90
Previous marks (0-100): 80

Student details:
Study hours: 8.0
Attendance: 90.0%
Previous marks: 80.0

AI prediction:
The student is likely to PASS.
```

The exact prediction is produced by the trained model. Do not treat the example as a guaranteed result.

## 7. How the code works

### `src/train_model.py`

1. `pd.read_csv()` loads the CSV file.
2. `X` selects the three input columns.
3. `y` selects the Pass/Fail label.
4. `train_test_split()` holds back 20% of the rows for testing.
5. `DecisionTreeClassifier()` creates the model.
6. `model.fit()` trains it.
7. `model.predict()` predicts labels for the test rows.
8. `accuracy_score()` calculates test accuracy.
9. `pickle.dump()` saves the trained model.

### `src/predict.py`

1. Loads the saved model with Pickle.
2. Asks the user for three values and validates them.
3. Creates a one-row Pandas DataFrame with the expected feature names.
4. Calls `model.predict()` to get the model's answer.
5. Prints the result.

## 8. Limitations

- The dataset is small and synthetic.
- The model may learn patterns that do not represent real students.
- Test accuracy on a tiny dataset can change depending on the split.
- Study habits and attendance alone cannot reliably determine exam results.
- The prediction is educational only and should not be used to label or judge real students.

## 9. Possible future improvements

- Collect a larger, ethically sourced and anonymized dataset.
- Visualize the decision tree.
- Compare a second simple ML algorithm.
- Create a small interface with Streamlit after understanding the Python version.

## 10. Conclusion

This project demonstrates a complete beginner-level supervised machine-learning workflow: load data, select features and labels, split data, train a model, evaluate it, save it and use it to make a prediction.
