@echo off
cd /d "%~dp0"
echo Installing project requirements...
py -m pip install -r requirements.txt
if errorlevel 1 (
    echo Installation failed. Check that Python and pip are installed.
    pause
    exit /b 1
)
echo.
echo Training the model...
py src\train_model.py
if errorlevel 1 (
    echo Training failed.
    pause
    exit /b 1
)
echo.
echo Starting prediction program...
py src\predict.py
pause
